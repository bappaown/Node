
var common = require('../test/common');
var http = require('http'),
    XLSX = require('xlsx'),
    util = require('util'),
    os = require('os'),
    formidable = common.formidable,
    port = common.port,
    server;


var workbook = XLSX.readFile('test.xlsx');
var sheet_name_list = workbook.SheetNames;
var xlData = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);
console.log(xlData);