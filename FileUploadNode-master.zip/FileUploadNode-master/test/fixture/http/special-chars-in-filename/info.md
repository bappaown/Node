* Opera does not allow submitting this file, it shows a warning to the
  user that the file could not be found instead. Tested in 9.8, 11.51 on OSX.
  Reported to Opera on 08.09.2011 (tracking email DSK-346009@bugs.opera.com).
