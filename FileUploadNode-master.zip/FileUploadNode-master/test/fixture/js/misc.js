module.exports = {
  'empty.http': [],
  'empty-urlencoded.http': [],
  'empty-multipart.http': [],
  'empty-multipart2.http': [],
  'minimal.http': [],
};
