﻿var Express = require('express');
var multer = require('multer');
var bodyParser = require('body-parser');
var app = Express();
var cfenv = require("cfenv");

var http = require('http'),
    XLSX = require('xlsx'),
    formidable = require('formidable'),
    port = 3000,
    server;

var filePath='';

var myurl = "https://69d6e768-dd84-49c5-b693-7469db4bf156-bluemix:59d2be1ffe8e9ddffd321a8e2b951d80a5f1ba0bbd831fceb0881acec6a3584a@69d6e768-dd84-49c5-b693-7469db4bf156-bluemix.cloudant.com";
var cloudant = require("cloudant")(myurl);
var mydb = cloudant.db.use("mydb");


app.use(bodyParser.json());

var Storage = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, "./fileupload");
    },
    filename: function (req, file, callback) {
        callback(null, Date.now() + "_" + file.originalname);
    }
});

var upload = multer({ storage: Storage }).array("imgUploader", 3); //Field name and max count

app.get("/", function (req, res) {
    res.sendFile(__dirname + "/index.html");
});

app.post("/", function (req, res) {
    upload(req, res, function (err) {
        if (err) {
            return res.end("Something went wrong!");
        }
        else
        {
        //Get file path    
        //var filePath;
        req.files.forEach(function(item) {
            filePath = './fileupload/' + item.filename;
         });

        //Read Excel data
        // var workbook = XLSX.readFile(filePath);
        // var sheet_name_list = workbook.SheetNames;
        // var xlData = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);

        //return res.end(JSON.stringify(xlData));
        return filePath;
        }
    });




    res.redirect(req.get('referer'));
});

app.post("/api/file", function (req, res) {
        // console.log(filePath);
        if (filePath)
        {
        var workbook = XLSX.readFile(filePath);
        var sheet_name_list = workbook.SheetNames;
        var xlData = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);
        
        // var jsonArr = [];
        
        // for(var myKey in xlData) {
        // jsonArr.push({
        // id: parseInt(myKey)+1,
        // name: xlData[myKey].Name,
        // employeeid : xlData[myKey].EmployeeId,
        // accountid : xlData[myKey].AccountId,
        // bookedhours : parseInt(xlData[myKey].BookedHours),
        // weekenddate : xlData[myKey].WeekEndDate,
        // });
        // }
       
        // mydb.insert({ 'detail': jsonArr}, '', 
        // function(err, data) {
        // console.log(err,data);
        // });

        
        // for(var myKey in xlData) {
        // var jsonArr = [];
        // jsonArr.push({
        // id: parseInt(myKey)+1,
        // name: xlData[myKey].Name,
        // employeeid : xlData[myKey].EmployeeId,
        // accountid : xlData[myKey].AccountId,
        // bookedhours : parseInt(xlData[myKey].BookedHours),
        // weekenddate : xlData[myKey].WeekEndDate,
        // });
    
        // mydb.insert({ 'details': jsonArr}, '', 
        // function(err, data) {
        // console.log(err,data);
        // });
        // }

        for(var myKey in xlData) {
        var myObj = {};
        myObj["name"] = xlData[myKey].Name;
        myObj["employeeid"] = xlData[myKey].EmployeeId;
        myObj["accountid"] = xlData[myKey].AccountId;
        myObj["bookedhours"] = xlData[myKey].BookedHours;
        myObj["weekenddate"] = xlData[myKey].WeekEndDate;

        mydb.insert(myObj, '', 
        function(err, data) {
        console.log(err,data);
        });
        }

        
        return res.send(JSON.stringify(xlData));
    }
    
    
});


app.post("/api/search", function (req, res) {
//    console.log(req.body.acc);
var cloudantquery = {
       "selector": {
      "accountid": req.body.acc
   },
   "fields": [
      "name",
      "employeeid",
      "accountid",
      "bookedhours",
      "weekenddate"
   ]
  };

  mydb.find(cloudantquery, function(err, data) {
      return res.send(JSON.stringify(data.docs));
});


});

app.listen(port, function (a) {
    console.log("Listening to port : http://localhost:" + port);
});