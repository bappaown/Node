﻿var Express = require('express');
var multer = require('multer');
var bodyParser = require('body-parser');
var app = Express();
var cfenv = require("cfenv");

var http = require('http'),
    XLSX = require('xlsx'),
    formidable = require('formidable'),
    port = 3000,
    server;

var filePath = '';

var myurl = "https://69d6e768-dd84-49c5-b693-7469db4bf156-bluemix:59d2be1ffe8e9ddffd321a8e2b951d80a5f1ba0bbd831fceb0881acec6a3584a@69d6e768-dd84-49c5-b693-7469db4bf156-bluemix.cloudant.com";
var cloudant = require("cloudant")(myurl);
var mydb = cloudant.db.use("prints");


app.use(bodyParser.json());
app.use(Express.static('public'));

var Storage = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, "./fileupload");
    },
    filename: function (req, file, callback) {
        callback(null, Date.now() + "_" + file.originalname);
    }
});

var upload = multer({ storage: Storage }).array("imgUploader", 3); //Field name and max count

app.get("/", function (req, res) {
    res.sendFile(__dirname + "/index.html");
});

app.post("/", function (req, res) {
    upload(req, res, function (err) {
        if (err) {
            return res.end("Something went wrong!");
        }
        else {
            //Get file path    
            //var filePath;
            req.files.forEach(function (item) {
                filePath = './fileupload/' + item.filename;
            });

            //Read Excel data
            // var workbook = XLSX.readFile(filePath);
            // var sheet_name_list = workbook.SheetNames;
            // var xlData = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);

            //return res.end(JSON.stringify(xlData));
            return filePath;
        }
    });

    res.redirect(req.get('referer'));
});

app.post("/api/file", function (req, res) {
    // console.log(filePath);
    if (filePath) {
        var workbook = XLSX.readFile(filePath);
        var sheet_name_list = workbook.SheetNames;
        var xlData = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);

        // var jsonArr = [];

        // for(var myKey in xlData) {
        // jsonArr.push({
        // id: parseInt(myKey)+1,
        // name: xlData[myKey].Name,
        // employeeid : xlData[myKey].EmployeeId,
        // accountid : xlData[myKey].AccountId,
        // bookedhours : parseInt(xlData[myKey].BookedHours),
        // weekenddate : xlData[myKey].WeekEndDate,
        // });
        // }

        // mydb.insert({ 'detail': jsonArr}, '', 
        // function(err, data) {
        // console.log(err,data);
        // });


        // for(var myKey in xlData) {
        // var jsonArr = [];
        // jsonArr.push({
        // id: parseInt(myKey)+1,
        // name: xlData[myKey].Name,
        // employeeid : xlData[myKey].EmployeeId,
        // accountid : xlData[myKey].AccountId,
        // bookedhours : parseInt(xlData[myKey].BookedHours),
        // weekenddate : xlData[myKey].WeekEndDate,
        // });

        // mydb.insert({ 'details': jsonArr}, '', 
        // function(err, data) {
        // console.log(err,data);
        // });
        // }

        for (var myKey in xlData) {
            var date = new Date(xlData[myKey].WeekEndingDate);
            var month = '' + (date.getMonth() + 1);
            var day = '' + date.getDate();
            var year = date.getFullYear();
            if (month.length < 2) month = '0' + month;
            if (day.length < 2) day = '0' + day;

            var myObj = {};
            myObj["Objtype"] = xlData[myKey].Objtype;
            myObj["AccountGroup"] = xlData[myKey].AccountGroup;
            myObj["AccountId"] = xlData[myKey].AccountId;
            myObj["WorkItemId"] = xlData[myKey].WorkItemId;
            myObj["EmpSerNum"] = xlData[myKey].EmpSerNum;
            myObj["EmpName"] = xlData[myKey].EmpName;
            myObj["Type"] = xlData[myKey].Type;
            myObj["Department"] = xlData[myKey].Department;
            myObj["ActivityCd"] = xlData[myKey].ActivityCd;
            myObj["ActvOwnDesc"] = xlData[myKey].ActvOwnDesc;
            myObj["Hours"] = parseInt(xlData[myKey].Hours);
            myObj["WeekEndingDate"] = month + '/' + day + '/' + year;
            myObj["WorkItemTitle"] = xlData[myKey].WorkItemTitle;
            myObj["NonRegularHoursInd"] = xlData[myKey].NonRegularHoursInd;
            myObj["MonthYear"] = month + '' + year;

            mydb.insert(myObj,
                function (err, data) {
                    console.log(err, data);
                });
        }
        
        filePath = '';
        return res.send(JSON.stringify(xlData));
    }
});


app.post("/api/search", function (req, res) {
    // console.log(req.body.month);

    var field = {};
    if (req.body.acc) {
        field.AccountId = req.body.acc;
    }
    if (req.body.date) {
        field.WeekEndingDate = req.body.date;
    }
    else if (req.body.month) {
        field.MonthYear = req.body.month;
    }

    var cloudantquery = {
        "selector": field,
        "fields": [
            "Objtype",
            "AccountGroup",
            "AccountId",
            "WorkItemId",
            "EmpSerNum",
            "EmpName",
            "Type",
            "Department",
            "ActivityCd",
            "ActvOwnDesc",
            "Hours",
            "WeekEndingDate",
            "WorkItemTitle",
            "NonRegularHoursInd"
        ]
    };

    mydb.find(cloudantquery, function (err, data) {
        // console.log(JSON.stringify(data.docs));
        if (typeof data !== "undefined") {
            return res.send(JSON.stringify(data.docs));
        }
    });


});

app.listen(port, function (a) {
    console.log("Listening to port : http://localhost:" + port);
});