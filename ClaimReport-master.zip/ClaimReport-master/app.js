﻿var Express = require('express');
var multer = require('multer');
var bodyParser = require('body-parser');
var app = Express();
var cfenv = require("cfenv");
var _ = require('lodash');

require('dotenv').config();

var http = require('http'),
    XLSX = require('xlsx'),
    formidable = require('formidable'),
    port = process.env.PORT || 3000,
    server;

function wait(ms) {
    var start = new Date().getTime();
    var end = start;
    while (end < start + ms) {
        end = new Date().getTime();
    }
}

var myurl = process.env.DB_URL;
var cloudant = require("cloudant")({ url: myurl, plugin: 'promises' });
var mydb = cloudant.db.use(process.env.DB_NAME);


app.use(bodyParser.json());
app.use(Express.static(__dirname + '/views'));

var Storage = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, "./fileupload");
    },
    filename: function (req, file, callback) {
        callback(null, Date.now() + "_" + file.originalname);
    }
});

var upload = multer({ storage: Storage }).array("imgUploader", 3); //Field name and max count

app.get("/", function (req, res) {
    res.sendFile(__dirname + "/index.html");
});

app.post("/", function (req, res) {
    upload(req, res, function (err) {
        var filePath;
        if (err) {
            return res.end("Something went wrong!");
        }
        else {
            //Get file path    
            req.files.forEach(function (item) {
                filePath = './fileupload/' + item.filename;
            });


            if (filePath) {
                var workbook = XLSX.readFile(filePath);
                var sheet_name_list = workbook.SheetNames;
                var xlData = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);

                let dat = [];
                let mylocalArr = [];
                for (var myKey in xlData) {
                    var date = new Date(xlData[myKey]['Week Ending Date']);
                    var month = '' + (date.getMonth() + 1);
                    var day = '' + date.getDate();
                    var year = date.getFullYear();
                    if (month.length < 2) month = '0' + month;
                    if (day.length < 2) day = '0' + day;

                    var myObj = {};
                    myObj["Objtype"] = 'Claim'; // xlData[myKey].Objtype;
                    myObj["AccountGroup"] = xlData[myKey]['Account Group'];
                    myObj["AccountId"] = xlData[myKey]['Account Id2'];
                    myObj["WorkItemId"] = xlData[myKey]['Work Item Id'];
                    myObj["EmpSerNum"] = xlData[myKey]['Emp Ser Num'];
                    myObj["EmpName"] = xlData[myKey]['Emp Last Name'];
                    myObj["Type"] = xlData[myKey]['Type'];
                    myObj["Department"] = xlData[myKey]['Department'];
                    myObj["ActivityCd"] = xlData[myKey]['Activity Cd'];
                    myObj["ActvOwnDesc"] = xlData[myKey]['Actv Own Desc'];
                    myObj["Hours"] = parseInt(xlData[myKey]['Hours']);
                    myObj["WeekEndingDate"] = month + '/' + day + '/' + year;
                    myObj["WorkItemTitle"] = xlData[myKey]['Work Item Title'];
                    myObj["NonRegularHoursInd"] = xlData[myKey]['Non-Regular Hours Ind'];
                    myObj["MonthYear"] = month + '' + year;

                    mylocalArr.push(myObj);

                    var field = {};
                    field.AccountId = myObj.AccountId;
                    field.WeekEndingDate = myObj.WeekEndingDate;
                    field.EmpSerNum = myObj.EmpSerNum;

                    var cloudantquery = {
                        "selector": field,
                        "fields": [
                            "_id",
                            "_rev"
                        ]
                    };

                    mydb.find(cloudantquery).then((data) => {
                        if (typeof data !== "undefined") {
                            if (data.docs.length > 0) {
                                if (data.docs[0]['_id'].length > 0) {
                                    mylocalArr[dat.length]['_id'] = data.docs[0]['_id'];
                                    mylocalArr[dat.length]['_rev'] = data.docs[0]['_rev'];
                                }
                            }
                        }

                        dat.push(mylocalArr[dat.length]);

                        if (dat.length == xlData.length) {
                            mydb.bulk({ docs: dat }).then(() => {
                                console.log('Success');
                                res.redirect('/?dbupdate=1');
                            }).catch((err) => {
                                console.log(err.message);
                                res.redirect('/?dbupdate=' + err.message);
                            })
                        }
                    }).catch((err) => {
                        dat.push(mylocalArr[dat.length]);
                        if (dat.length == xlData.length) {
                            mydb.bulk({ docs: dat }).then(() => {
                                console.log('Success');
                                res.redirect('/?dbupdate=1');
                            }).catch((err) => {
                                console.log(err.message);
                                res.redirect('/?dbupdate=' + err.message);
                            })
                        }
                        console.log(err.message);
                    });
                }
            }
            else {
                res.redirect('/?dbupdate=No Data');
            }
        }
    });

});

app.post("/api/email", function (req, res) {
    var myObjs = {};
    var field = {};
    field.EmpId = req.body.empid;
    field.Objtype = 'EmpDetail';

    var cloudantquery = {
        "selector": field,
        "fields": [
            "_id",
            "_rev",
            "Objtype",
            "EmpId",
            "Email"
        ]
    };

    mydb.find(cloudantquery).then((data) => {
        if (typeof data !== "undefined") {
            if (data.docs.length > 0) {
                if (data.docs[0]['_id'].length > 0) {
                    if (myObjs.Email === req.body.email) return;
                    myObjs = data.docs[0];
                    myObjs.Email = req.body.email;
                }
            } else {
                myObjs.Objtype = 'EmpDetail';
                myObjs.EmpId = req.body.empid;
                myObjs.Email = req.body.email;
            }
        } else {
            myObjs.Objtype = 'EmpDetail';
            myObjs.EmpId = req.body.empid;
            myObjs.Email = req.body.email;
        }
        mydb.insert(myObjs,
            function (err, data) {
                console.log(err, data);
            });
    });
});



function wait(ms, cb) {
    var waitDateOne = new Date();
    while ((new Date()) - waitDateOne <= ms) {
        //Nothing
    }
    if (cb) {
        eval(cb);
    }
}



function IsRecordExists(AccountId, EmpCode, WEDate, callback) {
    var field = {};
    field.AccountId = AccountId;
    field.WeekEndingDate = WEDate;
    field.EmpSerNum = EmpCode;

    var cloudantquery = {
        "selector": field,
        "fields": [
            "_id",
            "_rev"
        ]
    };

    mydb.find(cloudantquery, function (err, data) {
        if (typeof data !== "undefined") {
            callback(data.docs);
        } else {
            callback(null);
        }
    });
}

app.post("/api/search", function (req, res) {
    var myObjs = {};
    var field = {};
    if (req.body.acc) {
        field.AccountId = req.body.acc;
    }
    if (req.body.date) {
        field.WeekEndingDate = req.body.date;
    }
    else if (req.body.month) {
        field.MonthYear = req.body.month;
    }

    var cloudantquery = {
        "selector": field,
        "fields": [
            "Objtype",
            "AccountGroup",
            "AccountId",
            "WorkItemId",
            "EmpSerNum",
            "EmpName",
            "Type",
            "Department",
            "ActivityCd",
            "ActvOwnDesc",
            "Hours",
            "WeekEndingDate",
            "WorkItemTitle",
            "NonRegularHoursInd"
        ]
    };

    mydb.find(cloudantquery, function (err, data) {
        var dataWithEmpEmail = [];
        if (typeof data !== "undefined") {
            if (data.docs.length > 0) {

                var fields = {};
                // fields.EmpId = data[i]['EmpSerNum'];
                fields.Objtype = 'EmpDetail';

                var cloudantquerys = {
                    "selector": fields,
                    "fields": [
                        "EmpId",
                        "Email"
                    ]
                };

                mydb.find(cloudantquerys).then((value) => {
                    if (typeof value !== "undefined") {
                        if (value.docs.length > 0) {
                            var empDetails = value.docs;
                            data.docs.map((o) => {
                                let empItem = _.filter(empDetails, { 'EmpId': o.EmpSerNum });
                                if (empItem != null && empItem.length > 0) {
                                    dataWithEmpEmail.push({
                                        Objtype: o.Objtype,
                                        AccountGroup: o.AccountGroup,
                                        AccountId: o.AccountId,
                                        WorkItemId: o.WorkItemId,
                                        EmpSerNum: o.EmpSerNum,
                                        EmpName: o.EmpName,
                                        Type: o.Type,
                                        Department: o.Department,
                                        ActivityCd: o.ActivityCd,
                                        ActvOwnDesc: o.ActvOwnDesc,
                                        Hours: o.Hours,
                                        WeekEndingDate: o.WeekEndingDate,
                                        WorkItemTitle: o.WorkItemTitle,
                                        NonRegularHoursInd: o.NonRegularHoursInd,
                                        EmpEmail: empItem[0].Email
                                    });
                                } else {
                                    dataWithEmpEmail.push({
                                        Objtype: o.Objtype,
                                        AccountGroup: o.AccountGroup,
                                        AccountId: o.AccountId,
                                        WorkItemId: o.WorkItemId,
                                        EmpSerNum: o.EmpSerNum,
                                        EmpName: o.EmpName,
                                        Type: o.Type,
                                        Department: o.Department,
                                        ActivityCd: o.ActivityCd,
                                        ActvOwnDesc: o.ActvOwnDesc,
                                        Hours: o.Hours,
                                        WeekEndingDate: o.WeekEndingDate,
                                        WorkItemTitle: o.WorkItemTitle,
                                        NonRegularHoursInd: o.NonRegularHoursInd,
                                        EmpEmail: ''
                                    });
                                }
                            });

                            return res.send(JSON.stringify(dataWithEmpEmail));
                        }
                    }
                });
            }
            else {
                return res.send(JSON.stringify(dataWithEmpEmail));
            }
        }
        else {
            return res.send(JSON.stringify(dataWithEmpEmail));
        }
    });
});


function getRecord(data) {
    var fields = {};
    fields.EmpId = data;
    fields.Objtype = 'EmpDetail';

    var cloudantquerys = {
        "selector": fields,
        "fields": [
            "EmpId",
            "Email"
        ]
    };

    mydb.find(cloudantquerys).then((value) => {
        if (typeof value !== "undefined") {
            if (value.docs.length > 0) {
                console.log(JSON.stringify(value.docs));
                return JSON.stringify(value.docs);
            }
        }
    });
}

app.post("/api/account", function (req, res) {
    var cloudantquery = {
        "selector": {},
        "fields": [
            "AccountId"
        ]
    };

    mydb.find(cloudantquery, function (err, data) {
        if (typeof data !== "undefined") {
            return res.send(JSON.stringify(data.docs));
        }
    });
});

app.listen(port, function (a) {
    console.log("Listening to port : http://localhost:" + port);
});