﻿var Express = require('express');
var multer = require('multer');
var bodyParser = require('body-parser');
var app = Express();

var http = require('http'),
    XLSX = require('xlsx'),
    formidable = require('formidable'),
    port = 3000,
    server;

var filePath='';

app.use(bodyParser.json());

var Storage = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, "./fileupload");
    },
    filename: function (req, file, callback) {
        callback(null, Date.now() + "_" + file.originalname);
    }
});

var upload = multer({ storage: Storage }).array("imgUploader", 3); //Field name and max count

app.get("/", function (req, res) {
 
    res.sendFile(__dirname + "/index.html");
});

/*
var a = ()=>{
    var counter = 0;
    return ()=>{
        return counter += 1;
    }
}
*/

app.post("/", function (req, res) {
    upload(req, res, function (err) {
        if (err) {
            return res.end("Something went wrong!");
        }
        else
        {
        req.files.forEach(function(item) {
            filePath = './fileupload/' + item.filename;
         });
        return filePath;
        }
    });
    res.redirect(req.get('referer'));
});

app.post("/api/file", function (req, res) {
        if (filePath)
        {
        var workbook = XLSX.readFile(filePath);
        var sheet_name_list = workbook.SheetNames;
        var xlData = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);
        return res.send(JSON.stringify(xlData));
        }
});

app.listen(port, function (a) {
    console.log("Listening to port : http://localhost:" + port);
});