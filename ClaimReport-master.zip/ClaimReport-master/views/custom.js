
$(function () {
    $("#txtDate").datepicker({
        // dateFormat: 'mm/dd/y',
        beforeShowDay: function (date) {
            var day = date.getDay();
            return [day == 5, ''];
        }
    });

    var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
   
    for (var i = 11; i >= 0; i--) {
        var date = new Date(), year = date.getFullYear(), month = date.getMonth(), monthName = monthNames[date.getMonth()];
        var token = 12 - i + month;
        if (token >= 12) {
            token = token - 12;
        }
        else {
            year = parseInt(year) - 1;
        }
        monthName = monthNames[token];

        $("#ddlMonth").append($("<option></option>").attr("value", (token + 1) + '' + year).text(monthName + ', ' + year));
    }


    $('#BaseHour').each(function () {
        $(this).keyup(function () {
            this.value = this.value.replace(/[^\0-9]/ig, "");
        });
    });

    $('#BaseHour').keyup(function () {
        if ($(this).val() == "") {
            $(this).css('border', '1px solid red');
        }
        else {
            $(this).css('border', '1px solid #CCC');
        }
    });
    $('#ddlAccount').change(function () {
        if ($(this).val() == "") {
            $(this).css('border', '1px solid red');
        }
        else {
            $(this).css('border', '1px solid #CCC');
        }
    });
    $('#txtDate').change(function () {
        if ($(this).val() == "") {
            $(this).css('border', '1px solid red');
        }
        else {
            $(this).css('border', '1px solid #CCC');
        }
    });
    $('#ddlMonth').change(function () {
        if ($(this).val() == "") {
            $(this).css('border', '1px solid red');
        }
        else {
            $(this).css('border', '1px solid #CCC');
        }
    });

    // $('.required').each(function () {
    //     $(this).keyup(function () {
    //         ValidateControls();
    //     });
    // });

    // $('.require').each(function () {
    //     $(this).change(function () {
    //         ValidateControls();
    //     });
    // });


    $("#AllAccount").on("click", function () {
        $('#ddlAccount').css('border', '1px solid #CCC');
        if ($(this).is(":checked")) {
            $('#ddlAccount').prop('selectedIndex', 0);
            $('#ddlAccount').prop('disabled', true);
        }
        else {
            $('#ddlAccount').prop('selectedIndex', 0);
            $('#ddlAccount').prop('disabled', false);
        }
    });

    $("input[name='type']").on("change", function () {
        var type = $("input[name='type']:checked").val();
        $('#txtDate').css('border', '1px solid #CCC');
        $('#ddlMonth').css('border', '1px solid #CCC');
        if (type == 'Month') {
            $('#txtDate').css('display', 'none');
            $('#ddlMonth').css('display', 'block');
            $('#txtDate').val('');
            $('#ddlMonth').prop('selectedIndex', 0);
        }
        else if (type == 'Date') {
            $('#txtDate').css('display', 'block');
            $('#ddlMonth').css('display', 'none');
            $('#txtDate').val('');
            $('#ddlMonth').prop('selectedIndex', 0);
        }
    });

    $("#btndownload").click(function (e) {
        var clonedTable = $("#dvData").clone();

        $(clonedTable).find(".editable").each(function () {
            var text = $(this);
            text.after("<span>" + text.val() + "</span>");
            text.remove();
        })

        clonedTable.find('th:first-child, td:first-child').remove();
        clonedTable.find('[style*="display: none"]').remove();
        var html = clonedTable.html();
        // alert(html);

        var a = document.createElement('a');
        a.href = 'data:application/vnd.ms-excel,' + encodeURIComponent(html);
        a.download = "ClaimReport_" + $.now() + ".xls";
        document.body.appendChild(a);
        a.click();
        e.preventDefault();
    });

});


$(document).ready(function () {
    var options = {
        beforeSubmit: showRequest,  // pre-submit callback
        success: showResponse  // post-submit callback
    };

    // bind to the form's submit event
    $('#frmUploader').submit(function () {
        $('#modalLoading').modal('toggle');
        $(this).ajaxSubmit(options);
        // always return false to prevent standard browser submit and page navigation
        $('#modalLoading').modal('hide');

        return false;
    });
});

// pre-submit callback
function showRequest(formData, jqForm, options) {
    alert('Uploading is starting.');
    return true;
}

// post-submit callback
function showResponse(responseText, statusText, xhr, $form) {
    alert('status: ' + statusText + '\n\nresponseText: \n' + responseText);
}


// Validate Control Method
function ValidateControls() {
    var opt = 0;
    if ($('#BaseHour').val() == "") {
        $('#BaseHour').css('border', '1px solid red');
        opt = parseInt(opt) + 1;
    }
    else {
        $('#BaseHour').css('border', '1px solid #CCC');
        opt = parseInt(opt) + 0;
    }

    if (!$('#AllAccount')[0].checked) {
        if ($('#ddlAccount').prop('selectedIndex') > 0) {
            $('#ddlAccount').css('border', '1px solid #CCC');
            opt = parseInt(opt) + 0;
        }
        else {
            $('#ddlAccount').css('border', '1px solid Red');
            opt = parseInt(opt) + 1;
        }
    }
    else {
        $('#ddlAccount').css('border', '1px solid #CCC');
        opt = parseInt(opt) + 0;
    }

    var type = $("input[name='type']:checked").val();
    if (type == 'Date') {
        $('#ddlMonth').css('border', '1px solid #CCC');
        if ($('#txtDate').val() == "") {
            $('#txtDate').css('border', '1px solid red');
            opt = parseInt(opt) + 1;
        }
        else {
            $('#txtDate').css('border', '1px solid #CCC');
            opt = parseInt(opt) + 0;
        }
    }
    else if (type == 'Month') {
        $('#txtDate').css('border', '1px solid #CCC');
        if ($('#ddlMonth').prop('selectedIndex') > 0) {
            $('#ddlMonth').css('border', '1px solid #CCC');
            opt = parseInt(opt) + 0;
        }
        else {
            $('#ddlMonth').css('border', '1px solid red');
            opt = parseInt(opt) + 1;
        }
    }

    return opt;
}


function getParameterByName(name) {
    var url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}


$(document).ready(function () {
    var fullRecord = '';
    var dbupdate = getParameterByName('dbupdate');
    if (dbupdate != null) {
        if (dbupdate == '1')
            alert('Upload Successfull');
        else {
            //setTimeout(()=>{alert('Upload Successfull');},dbupdate*700); 
            alert(dbupdate);
        }
    }

    $('#Records').keyup(function () {
        this.value = this.value.replace(/[^\0-9]/ig, "");
        if ($(this).val() !== "") {
            $("#lower").text(1);
            $("#upper").text($(this).val());
            setTableData(fullRecord);
        }
    });

    $.ajax({
        url: "/api/account",
        type: "POST",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            var dupes = [];
            $.each(data, function (i, item) {
                if (!dupes[item.AccountId]) {
                    dupes[item.AccountId] = true;
                    $('#ddlAccount').append($("<option />").val(item.AccountId).text(item.AccountId));
                }
            });
        }
    });


    /* $.ajax({
         url: "/api/file",
         type: "POST",
         contentType: "application/json; charset=utf-8",
         dataType: "json",
         success: function (data) {
             // var res = JSON.stringify(data);
             $('#records_table').css('display', 'block');
             $('#aemp').click();
             $.each(data, function (i, item) {
                 $('<tr>').html("<td>" + data[i].Objtype + "</td><td>" + data[i].AccountGroup + "</td><td>" + data[i].AccountId + "</td><td>" + data[i].WorkItemId + "</td><td>" + data[i].EmpSerNum + "</td><td>" + data[i].EmpName + "</td><td>" + data[i].Type + "</td><td>" + data[i].Department + "</td><td>" + data[i].ActivityCd + "</td><td>" + data[i].ActvOwnDesc + "</td><td>" + data[i].Hours + "</td><td>" + data[i].WeekEndingDate + "</td><td>" + data[i].WorkItemTitle + "</td><td>" + data[i].NonRegularHoursInd + "</td>").appendTo('#records_table');
             });
         }
     });
 */
    $("#btnSearch").on("click", function () {
        var opt = ValidateControls();

        if (opt === 0) {
            $('#modalLoading').modal('toggle');
            var data = {};
            data.acc = $('#ddlAccount').val();
            data.date = $('#txtDate').val();
            data.month = $('#ddlMonth').val();
            $('#lblmsg').css('display', 'none');
            $.ajax({
                url: "/api/search",
                type: "POST",
                data: JSON.stringify(data),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (data) {
                    if (data.length > 0) {
                        $('#msg').css('display', 'none');
                        $('#btndownload').css('display', 'block');
                        $('#btnMail').css('display', 'block');
                        $('#dvRecord').css('display', 'block');
                        $('#search_record tr').has('td').remove();
                        var count = $("#Records").val();
                        $("#lower").text(1);
                        if (count) {
                            $("#upper").text(count);
                        }
                        else {
                            $("#upper").text(20);
                        }
                        fullRecord = data;
                        setTableData(data);

                        // $.each(data, function (i, item) {
                        //     var color = '';
                        //     var differ = '';
                        //     if ($('#BaseHour').val()) {
                        //         differ = parseInt($('#BaseHour').val()) - parseInt(data[i].Hours);
                        //         if (differ > 0) {
                        //             color = "Green";
                        //         }
                        //         else if (differ == 0) {
                        //             color = "Black";
                        //         }
                        //         else {
                        //             color = "Red";
                        //         }
                        //     }

                        //     $('<tr>').html("<td>" + data[i].AccountGroup + "</td><td>" + data[i].AccountId + "</td><td>" + data[i].WorkItemId + "</td><td>" + data[i].EmpSerNum + "</td><td>" + data[i].EmpName + "</td><td>" + data[i].Type + "</td><td>" + data[i].Department + "</td><td>" + data[i].ActivityCd + "</td><td>" + data[i].ActvOwnDesc + "</td><td>" + data[i].Hours + "</td><td>" + data[i].WeekEndingDate + "</td><td>" + data[i].WorkItemTitle + "</td><td>" + data[i].NonRegularHoursInd + "</td><td > <span style='color:" + color + "'>" + differ + "</span></td>").appendTo('#search_record');
                        // });
                    }
                    else {
                        $('#btndownload').css('display', 'none');
                        $('#btnMail').css('display', 'none');
                        $('#dvRecord').css('display', 'none');
                        $('#search_record tr').has('td').remove();
                        $('#msg').css('display', 'block');
                    }
                    $('#modalLoading').modal('hide');
                }
            });
        }
        else {
            $('#lblmsg').css('display', 'block');
        }
    });

    $("#btnNext").on("click", function () {
        var lower = $("#lower").text();
        var upper = $("#upper").text();
        var records = $("#Records").val();
        if (fullRecord.length > upper) {
            var update = parseInt(upper) + parseInt(records);
            $("#lower").text(parseInt(upper) + 1);
            $("#upper").text(update);
            setTableData(fullRecord);
        }
    });

    $("#btnPre").on("click", function () {
        var lower = $("#lower").text();
        var upper = $("#upper").text();
        var records = $("#Records").val();
        var update = parseInt(lower) - parseInt(records);
        if (update === 0)
            update = 1
        if (update > 0) {
            $("#lower").text(update);
            $("#upper").text(parseInt(lower) - 1);
        }
        setTableData(fullRecord);
    });

    $("#btnMail").on("click", function () {
        var mail = '';
        $("input[name='empid']").each(function () {
            if ($(this).prop('checked')) {
                // alert($(this).attr('id'));
                // alert($("input[name='emailid']").val());
                if ($("input[name=" + $(this).attr('id') + "]").val()) {
                    mail += $("input[name=" + $(this).attr('id') + "]").val() + ';';
                }
            }
        });

        if (mail) {
            var subject = 'Test Subject';
            var emailBody = 'Test Body';
            // window.location = 'mailto:' + mail + '?subject=' + subject + '&body=' + emailBody;
            window.open('mailto:' + mail + '?subject=' + subject + '&body=' + emailBody, '_blank');
        }
        else {
            alert('Please select the proper Email!');
        }

    });

});

function setTableData(data) {

    if (data.length < $("#upper").text())
        $("#upper").text(data.length);
    var lower = $("#lower").text();
    var upper = $("#upper").text();
    $('#search_record tr').has('td').remove();
    for (var i = parseInt(lower) - 1; i < parseInt(upper); i++) {
        var color = '';
        var differ = '';
        if ($('#BaseHour').val()) {
            differ = parseInt($('#BaseHour').val()) - parseInt(data[i].Hours);
            if (differ > 0) {
                color = "Green";
            }
            else if (differ == 0) {
                color = "Black";
            }
            else {
                color = "Red";
            }
        }

        // alert(data[i].EmpSerNum);

        $('<tr>').html("<td><input type='checkbox' name='empid' id='" + data[i].EmpSerNum + "' /></td><td>" + data[i].AccountGroup + "</td><td>" + data[i].AccountId + "</td><td>" + data[i].WorkItemId + "</td><td>" + data[i].EmpSerNum + "</td><td>" + data[i].EmpName + "</td><td>" + data[i].Type + "</td><td>" + data[i].Department + "</td><td>" + data[i].ActivityCd + "</td><td>" + data[i].ActvOwnDesc + "</td><td>" + data[i].Hours + "</td><td>" + data[i].WeekEndingDate + "</td><td>" + data[i].WorkItemTitle + "</td><td>" + data[i].NonRegularHoursInd + "</td><td> <span style='color:" + color + "'>" + differ + "</span></td><td><input type='text' onblur ='doSomething(this);' class='editable'  name='" + data[i].EmpSerNum + "' value='" + data[i].EmpEmail + "'  /></td>").appendTo('#search_record');
    }

    customizeColumn();
}

function customizeColumn() {
    var $tblhead = $("#search_record th");

    if ($('#cbAccountGroup').prop("checked")) {
        var colToHide = $tblhead.filter("#thAccountGroup");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').show();
    }
    else {
        var colToHide = $tblhead.filter("#thAccountGroup");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').hide();
    }
    if ($('#cbAccountId').prop("checked")) {
        var colToHide = $tblhead.filter("#thAccountId");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').show();
    }
    else {
        var colToHide = $tblhead.filter("#thAccountId");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').hide();
    }
    if ($('#cbWorkItemId').prop("checked")) {
        var colToHide = $tblhead.filter("#thWorkItemId");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').show();
    }
    else {
        var colToHide = $tblhead.filter("#thWorkItemId");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').hide();
    }
    if ($('#cbEmpSerNum').prop("checked")) {
        var colToHide = $tblhead.filter("#thEmpSerNum");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').show();
    }
    else {
        var colToHide = $tblhead.filter("#thEmpSerNum");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').hide();
    }
    if ($('#cbEmpName').prop("checked")) {
        var colToHide = $tblhead.filter("#thEmpName");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').show();
    }
    else {
        var colToHide = $tblhead.filter("#thEmpName");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').hide();
    }
    if ($('#cbType').prop("checked")) {
        var colToHide = $tblhead.filter("#thType");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').show();
    }
    else {
        var colToHide = $tblhead.filter("#thType");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').hide();
    }
    if ($('#cbDepartment').prop("checked")) {
        var colToHide = $tblhead.filter("#thDepartment");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').show();
    }
    else {
        var colToHide = $tblhead.filter("#thDepartment");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').hide();
    }
    if ($('#cbActivityCd').prop("checked")) {
        var colToHide = $tblhead.filter("#thActivityCd");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').show();
    }
    else {
        var colToHide = $tblhead.filter("#thActivityCd");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').hide();
    }
    if ($('#cbActvOwnDesc').prop("checked")) {
        var colToHide = $tblhead.filter("#thActvOwnDesc");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').show();
    }
    else {
        var colToHide = $tblhead.filter("#thActvOwnDesc");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').hide();
    }
    if ($('#cbHours').prop("checked")) {
        var colToHide = $tblhead.filter("#thHours");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').show();
    }
    else {
        var colToHide = $tblhead.filter("#thHours");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').hide();
    }
    if ($('#cbWeekEndingDate').prop("checked")) {
        var colToHide = $tblhead.filter("#thWeekEndingDate");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').show();
    }
    else {
        var colToHide = $tblhead.filter("#thWeekEndingDate");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').hide();
    }
    if ($('#cbWorkItemTitle').prop("checked")) {
        var colToHide = $tblhead.filter("#thWorkItemTitle");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').show();
    }
    else {
        var colToHide = $tblhead.filter("#thWorkItemTitle");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').hide();
    }
    if ($('#cbNonRegularHoursInd').prop("checked")) {
        var colToHide = $tblhead.filter("#thNonRegularHoursInd");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').show();
    }
    else {
        var colToHide = $tblhead.filter("#thNonRegularHoursInd");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').hide();
    }
    if ($('#cbDifference').prop("checked")) {
        var colToHide = $tblhead.filter("#thDifference");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').show();
    }
    else {
        var colToHide = $tblhead.filter("#thDifference");
        var index = $(colToHide).index();
        $("#search_record").find('tr :nth-child(' + (index + 1) + ')').hide();
    }

}

function doSomething(emp) {
    // alert(emp.getAttribute('name'));
    var data = {};
    data.empid = emp.getAttribute('name');
    data.email = $(emp).val();

    var testEmail = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
    if (testEmail.test($(emp).val())) {
        $.ajax({
            url: "/api/email",
            type: "POST",
            data: JSON.stringify(data),
            contentType: "application/json; charset=utf-8",
            dataType: "json"
        });
    }
}
