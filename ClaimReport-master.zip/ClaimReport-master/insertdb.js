var myurl = "https://69d6e768-dd84-49c5-b693-7469db4bf156-bluemix:59d2be1ffe8e9ddffd321a8e2b951d80a5f1ba0bbd831fceb0881acec6a3584a@69d6e768-dd84-49c5-b693-7469db4bf156-bluemix.cloudant.com";
var cloudant = require("cloudant")(myurl);
var mydb = cloudant.db.use("prints");
mydb.insert({ 'employee': [
    	{ 
    	  'id' : 1, 
    	  'team':  'PLM' ,
          'name': "Jaydeep Ghosh"  ,
          'designation': 'Sr. System Engineer' ,
           'role': 'Peer'},
     	{
     	  'id' : 2,
     	  'team':  'Leaf' ,
          'name': "Bappaditya Mondal"  ,
          'designation': 'Application Developer' ,
           'role': 'Peer'},
    	{
    	  'id' : 3,
    	  'team':  'PLM' ,
          'name': "Sukhendu Mukherjee"  ,
          'designation': 'Project Manager' ,
           'role': 'Manager'},
    	]}, 'employee', 
function(err, data) {
  console.log(err,data);
});